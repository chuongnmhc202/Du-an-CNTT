Đường dẫn tới tập dữ liệu Việt - Tây Ban Nha gốc : 
https://www.kaggle.com/datasets/duy52000751/data-vi-es

Đường dẫn tới tập dữ liệu Anh - Tây Ban Nha, Anh - Việt gốc:
https://www.kaggle.com/datasets/duy52000751/data-du-an-cong-nghe-thong-tin


Đường dẫn tới mô hình đa ngữ sau khi train: 
https://www.kaggle.com/datasets/vnduytrn/mt5-da-ngu

Đường dẫn tới mô hình song ngữ sau khi train: 
https://www.kaggle.com/datasets/vnduytrn/mt5-song-ngu
